DESCRIPTION
================================================================================

Table-Movielens1M extends the original Movielens-1M dataset (https://grouplens.org/datasets/movielens/1m/) with enriched movie data. This new version contains 6040 users, 3883 movies, and 1000209 ratings. Leveraging each MovielensID's corresponding movie page on movielens.org, we further fetch some "time-invariant" metadata for movies, including: Director, Cast, Runtime, Languages, Certificate, Plot, and Url.

We have also prepared embeddings for movies with all-MiniLM-L6-v2 model, see embeddings.npy in zipfile.

The basic task is to classify users' age phase.

ENHANCED MOVIE DATA FORMAT
================================================================================

movies.csv follows the format outlined below:
MovielensID,Title,Year,Genre,Director,Cast,Runtime,Languages,Certificate,Plot,Url

- MovielensID: This is the movie's id on the movielens website, inherited from the original Movielens-1M dataset.
- Title: The title of the movie, sourced from the movielens website.
- Year: The release year of the movie, sourced from the movielens website.
- Genre: Movie genres, inherited from the original Movielens-1M dataset.
- Director: The director's name of the movie, sourced from the movielens website.
- Cast: The main cast of the movie, sourced from the movielens website.
- Runtime: The duration of the movie, sourced from the movielens website.
- Languages: Official language versions of the movie, sourced from the movielens website.
- Certificate: Movie certificate information, sourced from the movielens website.
- Plot: A brief summary of the movie's main plot, sourced from the movielens website.
- Url: The movie's URL on the movielens website.

SOME SPECIAL NOTES
================================================================================

1. Please note that due to the age of the Movielens-1M dataset, some MovielensID values no longer correspond to actual pages, meaning there is a discrepancy between MovielensID and the actual page ID on the movielens website.

For movies facing this issue, we have extracted information from their actual pages. However, to minimize changes, we have not modified their MovielensID. Here is a list of such movies with their MovielensID and real ID:

   * 3589: Original ID changed to 54605
   * 557: Original ID changed to 8739
   * 578: Original ID changed to 6531
   * 669: Original ID changed to 6918
   * 863: Original ID changed to 193303
   * 978: Original ID changed to 4970
   * 1108: Original ID changed to 6677
   * 1205: Original ID changed to 4006
   * 1294: Original ID changed to 5060
   * 1362: Original ID changed to 4424
   * 1494: Original ID changed to 6425
   * 1868: Original ID changed to 6474
   * 2645: Original ID changed to 5649
   * 3027: Original ID changed to 203829
   * 3366: Original ID changed to 6808
   * 3416: Original ID changed to 6460
   * 3482: Original ID changed to 72267
   * 3532: Original ID changed to 5560
   * 3842: Original ID changed to 5717
   * 3935: Original ID changed to 6910

1. Additionally, there are some other issues:
	
   * Movie with MovielensID 2228 in movielens is missing, so we use information from IMDB.
   * Movies with MovielensID 1741 and 1758 are duplicates of 1795 and 2563 respectively.

2. Users and Ratings file are followed original format.


---------------- The Following is Movielens-1m's original Readme ----------------
SUMMARY
================================================================================

These files contain 1,000,209 anonymous ratings of approximately 3,900 movies 
made by 6,040 MovieLens users who joined MovieLens in 2000.

USAGE LICENSE
================================================================================

Neither the University of Minnesota nor any of the researchers
involved can guarantee the correctness of the data, its suitability
for any particular purpose, or the validity of results based on the
use of the data set.  The data set may be used for any research
purposes under the following conditions:

     * The user may not state or imply any endorsement from the
       University of Minnesota or the GroupLens Research Group.

     * The user must acknowledge the use of the data set in
       publications resulting from the use of the data set
       (see below for citation information).

     * The user may not redistribute the data without separate
       permission.

     * The user may not use this information for any commercial or
       revenue-bearing purposes without first obtaining permission
       from a faculty member of the GroupLens Research Project at the
       University of Minnesota.

If you have any further questions or comments, please contact GroupLens
<grouplens-info@cs.umn.edu>. 

CITATION
================================================================================

To acknowledge use of the dataset in publications, please cite the following
paper:

F. Maxwell Harper and Joseph A. Konstan. 2015. The MovieLens Datasets: History
and Context. ACM Transactions on Interactive Intelligent Systems (TiiS) 5, 4,
Article 19 (December 2015), 19 pages. DOI=http://dx.doi.org/10.1145/2827872


ACKNOWLEDGEMENTS
================================================================================

Thanks to Shyong Lam and Jon Herlocker for cleaning up and generating the data
set.

FURTHER INFORMATION ABOUT THE GROUPLENS RESEARCH PROJECT
================================================================================

The GroupLens Research Project is a research group in the Department of 
Computer Science and Engineering at the University of Minnesota. Members of 
the GroupLens Research Project are involved in many research projects related 
to the fields of information filtering, collaborative filtering, and 
recommender systems. The project is lead by professors John Riedl and Joseph 
Konstan. The project began to explore automated collaborative filtering in 
1992, but is most well known for its world wide trial of an automated 
collaborative filtering system for Usenet news in 1996. Since then the project 
has expanded its scope to research overall information filtering solutions, 
integrating in content-based methods as well as improving current collaborative 
filtering technology.

Further information on the GroupLens Research project, including research 
publications, can be found at the following web site:
        
        http://www.grouplens.org/

GroupLens Research currently operates a movie recommender based on 
collaborative filtering:

        http://www.movielens.org/

RATINGS FILE DESCRIPTION
================================================================================

All ratings are contained in the file "ratings.dat" and are in the
following format:

UserID::MovieID::Rating::Timestamp

- UserIDs range between 1 and 6040 
- MovieIDs range between 1 and 3952
- Ratings are made on a 5-star scale (whole-star ratings only)
- Timestamp is represented in seconds since the epoch as returned by time(2)
- Each user has at least 20 ratings

USERS FILE DESCRIPTION
================================================================================

User information is in the file "users.dat" and is in the following
format:

UserID::Gender::Age::Occupation::Zip-code

All demographic information is provided voluntarily by the users and is
not checked for accuracy.  Only users who have provided some demographic
information are included in this data set.

- Gender is denoted by a "M" for male and "F" for female
- Age is chosen from the following ranges:

	*  1:  "Under 18"
	* 18:  "18-24"
	* 25:  "25-34"
	* 35:  "35-44"
	* 45:  "45-49"
	* 50:  "50-55"
	* 56:  "56+"

- Occupation is chosen from the following choices:

	*  0:  "other" or not specified
	*  1:  "academic/educator"
	*  2:  "artist"
	*  3:  "clerical/admin"
	*  4:  "college/grad student"
	*  5:  "customer service"
	*  6:  "doctor/health care"
	*  7:  "executive/managerial"
	*  8:  "farmer"
	*  9:  "homemaker"
	* 10:  "K-12 student"
	* 11:  "lawyer"
	* 12:  "programmer"
	* 13:  "retired"
	* 14:  "sales/marketing"
	* 15:  "scientist"
	* 16:  "self-employed"
	* 17:  "technician/engineer"
	* 18:  "tradesman/craftsman"
	* 19:  "unemployed"
	* 20:  "writer"

MOVIES FILE DESCRIPTION
================================================================================

Movie information is in the file "movies.dat" and is in the following
format:

MovieID::Title::Genres

- Titles are identical to titles provided by the IMDB (including
year of release)
- Genres are pipe-separated and are selected from the following genres:

	* Action
	* Adventure
	* Animation
	* Children's
	* Comedy
	* Crime
	* Documentary
	* Drama
	* Fantasy
	* Film-Noir
	* Horror
	* Musical
	* Mystery
	* Romance
	* Sci-Fi
	* Thriller
	* War
	* Western

- Some MovieIDs do not correspond to a movie due to accidental duplicate
entries and/or test entries
- Movies are mostly entered by hand, so errors and inconsistencies may exist
