# TACM12K

**Table-ACM12K (TACM12K)** is a relational table dataset reorganized from the ACM heterogeneous graph dataset[1]. It includes four tables: papers, authors, Paper-Author relationships, and citation relationships. The paper features include year, title, and abstract, while author features include name and affiliation. Additionally, we label the papers based on the conferences in which they were published.

## Processed

First, we created the Author table by extracting the original authors' IDs and names from the file. We added the firm information to each author based on the 'AvsF' data, resulting in the Author table (17431 entries).

Next, we worked on the Paper table, manually annotating the year information for the venues. Using the 'PvsV' matrix, we added the year attribute to the Paper entries. Due to mislabeling in the original data where the STOC conference was incorrectly marked as the COLT conference in the "PvsC" matrix, we corrected this in the "VvsC" matrix. We then recalculated the PvsV * VvsC to obtain the corrected PvsC matrix, ultimately assigning the conference attribute to each paper. The number of papers per conference is shown in Table 1.

The original dataset contained text information for each paper as a concatenation of title and abstract. To make this structure clearer, we utilized three methods to extract the title from the original text information:
1. Use the scholarly library in Python to accurately query the last two sentences of the original text.
2. Utilize the Tongyi Qianwen language model to extract the title from the original text.
3. Match the abstract in the Aminer dataset [tj2008Aminer] to obtain the title.

We then compared the results of these three methods. If two results were the same, we considered it the title. If all three results differed, we manually verified and supplemented the title information. This process allowed us to separate the original text into a distinct title and abstract. Additionally, we supplemented some incomplete abstracts.

The Write table inherited the "PvsA" matrix from the original data. The Cite table inherited the "PvsP" matrix from the original data.

- 

<center>Table 1: Each conference corresponds to its number of papers</center>

| Conference | Number | Conference | Number |
| :--------: | :----: | :--------: | :----: |
|    KDD     |  1061  |    SOSP    |  332   |
|   SIGMOD   |  1417  |    SPAA    |  473   |
|    WWW     |  1653  |  SIGCOMM   |  648   |
|   SIGIR    |  1572  |  MobiCOMM  |  322   |
|    CIKM    |  1724  |    ICML    |  456   |
|    SODA    |  662   |    COLT    |   83   |
|    STOC    |  1519  |    VLDB    |  577   |

## Content

- paper.csv: It contains 12,499 papers of 14 conferences in different years, in which each row of data is the paper's unique identification paper_id, publication year, published conference, title of the paper, and abstract of the paper.
- author.csv: It includes 17,431 authors, each with a unique identification of author_id, name, and firm or organization for which they work.
- cite.csv: A total of 30789 paper citation relationships are included, two of which are listed as paper_id and paper_id_cited, that is, the former cited the latter.
- paper_author.csv: It includes 37055 papers and author relationships, and each line is paper ID paper_id and author ID author_id. A paper may have multiple authors.
- masks.pt: The training set (280), verification set(500) and test set(1000) are divided. The training set selected 20 papers for each category. While the verification set and the test set meet the natural distribution law as much as possible, the balance adjustment is made so that the number of papers in the least category and the number of papers in the most category are not more than four times.
- paper_embeddings.npy: The paper information embedding was carried out using the "all-MiniLM-L6-v2" model.
- author_embeddings.npy: The author information embedding was carried out using the "all-MiniLM-L6-v2" model.

## Refferences

[1]. Wang X, Ji H, Shi C, et al. Heterogeneous graph attention network[C]//The world wide web conference. 2019: 2022-2032.

[2]. Tang J, Zhang J, Yao L, et al. Arnetminer: extraction and mining of academic social networks[C]//Proceedings of the 14th ACM SIGKDD international conference on Knowledge discovery and data mining. 2008: 990-998.